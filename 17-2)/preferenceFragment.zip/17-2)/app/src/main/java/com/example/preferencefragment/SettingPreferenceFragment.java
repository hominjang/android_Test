package com.example.preferencefragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SettingPreferenceFragment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_preference_fragment);
    }
}